This is a library for our Monochrome OLEDs based on SSD1305 drivers

Pick one up today in the adafruit shop!

  * https://www.adafruit.com/products/2675

These displays use I2C or SPI to communicate

Adafruit invests time and resources providing this open source code, 
please support Adafruit and open-source hardware by purchasing 
products from Adafruit!

Written by Limor Fried/Ladyada  for Adafruit Industries.  
BSD license, check license.txt for more information
All text above must be included in any redistribution

To install, use the Arduino Library Manager and search for 'Adafruit SSD1305' and install the library

This library depends on the Adafruit GFX library, which can also be installed via the Arduino Library Manager
